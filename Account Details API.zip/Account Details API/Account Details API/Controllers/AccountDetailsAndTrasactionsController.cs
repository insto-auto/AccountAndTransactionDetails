﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Account_Details_API.Business_Logic;
using Account_Details_API.Models;
using System.Text.Json;
using Newtonsoft.Json;
using System.Web;

namespace Account_Details_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountDetailsAndTrasactionsController : ControllerBase
    {
        Acount_And_Transaction_Details objActTransDetails = new Acount_And_Transaction_Details();
        [HttpGet]
        public String getAccountDetails(int userID)
        { 
            List<AccountDetails> lstaccountDetails = new List<AccountDetails>();
            try
            {
                lstaccountDetails= objActTransDetails.getAccountDetails(userID);
                
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return JsonConvert.SerializeObject(lstaccountDetails);
        }
        [HttpGet]
        public String getTransactionDetails(int AccountNumber)
        {
            
            List<TransactionDetails> lstTransactionDetails = new List<TransactionDetails>();
            TransactionDetails objtransdetails = new TransactionDetails();
            
            try
            {
                lstTransactionDetails = objActTransDetails.getTransactionDetails();
                objtransdetails=lstTransactionDetails.Where(x => x.AccountNumber == AccountNumber).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;

            }
            return JsonConvert.SerializeObject(objtransdetails);
        }
    }
}