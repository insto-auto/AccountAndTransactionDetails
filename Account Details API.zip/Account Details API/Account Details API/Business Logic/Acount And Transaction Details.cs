﻿using Account_Details_API.Models;
//using Microsoft.Data.SqlClient; 
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Account_Details_API.Business_Logic
{
    public class Acount_And_Transaction_Details
    {
        String connetionString = "Data Source=ServerName;Initial Catalog=DatabaseName;User ID=UserName;Password=Password;Integrated Security = True";
        public List<AccountDetails> getAccountDetails(int userID)
        {
            List<AccountDetails> lstAccountDetails = new List<AccountDetails>();
            try
            {

                using (SqlConnection myConnection = new SqlConnection(connetionString))
                {
                    string sqlQuery = "Select * from AccountDetails where AccountNumber=(Select AccountNumber From User where UserID=@userID)";
                    SqlCommand cmd = new SqlCommand(sqlQuery, myConnection);
                    cmd.Parameters.AddWithValue("@UserID", userID);
                    myConnection.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        AccountDetails acDetails = new AccountDetails();
                        acDetails.AccountNumber = Convert.ToInt32(dr["AccountNumber"].ToString());
                        acDetails.AccountName = dr["AccountName"].ToString();
                        acDetails.AccountType = dr["AccountType"].ToString();
                        acDetails.BalanceDate = Convert.ToDateTime(dr["BalanceDate"].ToString());
                        acDetails.Currency = dr["Currency"].ToString();
                        acDetails.OpeningAvailableBalance = dr["OpeningAvailableBalance"].ToString();
                        lstAccountDetails.Add(acDetails);
                    }
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }

            return lstAccountDetails;
        }
        public List<TransactionDetails> getTransactionDetails()
        {
            List<TransactionDetails> lsttransactionDetails = new List<TransactionDetails>();
            try
            {

                using (SqlConnection myConnection = new SqlConnection(connetionString))
                {

                    string sqlQuery = "Select * from TransactionDetails";
                    SqlCommand cmd = new SqlCommand(sqlQuery, myConnection);

                    myConnection.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        TransactionDetails transDetails = new TransactionDetails();
                        transDetails.AccountNumber = Convert.ToInt32(dr["AccountNumber"].ToString());
                        transDetails.AccountName = dr["AccountName"].ToString();
                        transDetails.DebitAMount = dr["DebitAMount"].ToString();
                        transDetails.ValueDate = Convert.ToDateTime(dr["ValueDate"].ToString());
                        transDetails.Currency = dr["Currency"].ToString();
                        transDetails.CreditAmount = dr["CreditAmount"].ToString();
                        transDetails.DebitCredit = dr["DebitCredit"].ToString();
                        transDetails.TransactionNarrative = dr["TransactionNarrative"].ToString();
                        lsttransactionDetails.Add(transDetails);
                    }
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lsttransactionDetails;

        }
       
    }
       
       
}
