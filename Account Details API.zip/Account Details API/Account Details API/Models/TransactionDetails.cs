﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Account_Details_API.Models
{
    public class TransactionDetails
    {        
        public Int32 AccountNumber { get; set; }
        public String AccountName { set; get; }
        public DateTime ValueDate { set; get; }
        public String Currency { set; get; }
        public String DebitAMount { set; get; }
        public String CreditAmount { set; get; }
        public String DebitCredit { set; get; }
        public String TransactionNarrative { set; get; }
    }
}
