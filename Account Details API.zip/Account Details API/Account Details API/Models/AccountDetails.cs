﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Account_Details_API.Models
{
    public class AccountDetails
    {
        public Int32 AccountNumber { get; set; }
        public String AccountName { set; get; }
        public String AccountType { set; get; }
        public DateTime BalanceDate { set; get; }
        public String Currency { set; get; }
        public String OpeningAvailableBalance { set; get; }

    }
}
