using Microsoft.VisualStudio.TestTools.UnitTesting;
using Account_Details_API.Controllers;
namespace AccountAndTransactionDetailsTestCases
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void AccountDetails()
        {
            AccountDetailsAndTrasactionsController objtest = new AccountDetailsAndTrasactionsController();
           string result = objtest.getAccountDetails(1);
        }
        [TestMethod]
        public void TransactionDetais()
        {
            AccountDetailsAndTrasactionsController objtest = new AccountDetailsAndTrasactionsController();
            string result = objtest.getTransactionDetails(178346634);
        }
    }
}
